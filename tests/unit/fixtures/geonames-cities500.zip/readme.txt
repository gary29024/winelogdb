Stored without compression.
